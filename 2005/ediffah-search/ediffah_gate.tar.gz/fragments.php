<?php

$sidhuvud = utf8_encode('<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
  <head>
    <title>Ediffah &mdash; Enkel s�kning</title>
    <link rel="stylesheet" href="/css-style/html.css" />
    <meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
  </head>');


$sidhuvud_scan = utf8_encode('<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
  <head>
    <title>Ediffah &mdash; Bl�ddra indexeringstermer</title>
    <link rel="stylesheet" href="/css-style/html.css" />
    <meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
  </head>');


$sidhuvud_avancerad = utf8_encode('<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
  <head>
    <title>Ediffah &mdash; Avancerade s�kning</title>
    <link rel="stylesheet" href="/css-style/html.css" />
    <meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
  </head>');


$rubrikinfo = utf8_encode('

  <body>

    <div class="box">    
    <a href="./">
       <img src="/2004/ediffah/ediffah.jpg"
           class="right"
	   alt="Ediffah &mdash; En Digital Infrastruktur f�r Forskningsbibliotekens Arkiv- och Handskriftssamlingar" border="0"/></a>
');
$rubrik = utf8_encode('
      <h1 class="logo" >
	<b>Ediffah</b><br />&mdash; En prototyp f�r en s�kmaskin</h1>');

$rubrik_scan = utf8_encode('
      <h1 class="logo" >
	<b>Ediffah</b><br />&mdash; Bl�ddra indexeringstermer (prototyp)</h1>');

$rubrik_avancerad = utf8_encode('
      <h1 class="logo" >
	<b>Ediffah</b><br />&mdash; Avancerad s�kning (protyp)</h1>');


$topinfo = utf8_encode('

    <p>Detta �r en tj�nst i vardande. Allt h�r �r prelimin�rt, men kan
        f�r tillf�llet anses vara stabilt.
	Notera att posterna i databasen �r inte p� n�got s�tt �r representativa f�r f�r
	de deltagande bibliotekens samlingar.
	L�s g�rna mer <a href="http://www.lub.lu.se/ediffah/">om Ediffah</a>
	och om hur vi
	<a href="http://sigge.lub.lu.se/2004/ediffah/finding-aids/">f�rtecknar arkiv</a>.</p>
	<dl>
	<dt><strong>Prelimin�ra s�km�jligheter</strong><br/></dt>
	<dd>');

$menu =  utf8_encode('
	[ <a href="http://sigge.lub.lu.se/2005/ediffah-search/">Enkel s�kning</a> ||
	  <a href="http://sigge.lub.lu.se/2005/ediffah-search/advanced.php">Avancerad s�kning</a> ||
          <a href="http://sigge.lub.lu.se/2005/ediffah-search/scan.php">Indexeringstermer</a> ]
	</dd></dl>

    <br clear="all" />

');

$menu_simple =  utf8_encode('
	[ <strong>Enkel s�kning</strong> ||
	  <a href="http://sigge.lub.lu.se/2005/ediffah-search/advanced.php">Avancerad s�kning</a> ||
          <a href="http://sigge.lub.lu.se/2005/ediffah-search/scan.php">Indexeringstermer</a> ]
	</dd></dl>

    <br clear="all" />

');

$menu_scan =  utf8_encode('
	[ <a href="http://sigge.lub.lu.se/2005/ediffah-search/">Enkel s�kning</a> ||
	  <a href="http://sigge.lub.lu.se/2005/ediffah-search/advanced.php">Avancerad s�kning</a> ||
          <strong>Indexeringstermer</strong> ]
	</dd></dl>

    <br clear="all" />

');

$menu_avancerad =  utf8_encode('
	[ <a href="http://sigge.lub.lu.se/2005/ediffah-search/">Enkel s�kning</a> ||
	  <strong>Avancerad s�kning</strong> ||
          <a href="http://sigge.lub.lu.se/2005/ediffah-search/scan.php">Indexeringstermer</a> ]
	</dd></dl>

    <br clear="all" />

');

$sidhuvud_simple = $sidhuvud.$rubrikinfo.$rubrik.$topinfo.$menu_simple;
$sidhuvud = $sidhuvud.$rubrikinfo.$rubrik.$topinfo.$menu;
$sidhuvud_scan = $sidhuvud_scan.$rubrikinfo.$rubrik_scan.$topinfo.$menu_scan;
$sidhuvud_avancerad = $sidhuvud_avancerad.$rubrikinfo.$rubrik_avancerad.$topinfo.$menu_avancerad;

$sidfot = utf8_encode('
	<br />
	</div>
  </body>
</html>
');

$sidfot_start = utf8_encode('
	<br />
        <p>
          Alla program som anv�nds i tj�nsten finns beskrivna i <a href="README">README</a>, och
          du kan sj�lv ladda ner dem som ett g-zippat tar-arkiv,
          <a href="./ediffah_gate.tar.gz">ediffah_gate.tar.gz</a>
        </p>
	<br />
	</div>
  </body>
</html>
');


?>
