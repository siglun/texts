<?php
require('./globals.php');	

initservice();

require('./fragments.php');
print ($sidhuvud_simple);
print utf8_encode('
	  <form action="./search.php" method="get">
          <input name="presentation" value="brief" type="hidden" />
          <input name="start" value="1" type="hidden" />
          <input name="number" value="10" type="hidden" />

	  <table class="navigation">

	    <tr  class="navigation">
	      <td colspan="2"   class="left">
		<input name="searchfield[1]" type="hidden" value="any" />
                  <strong>Fyll i s�kord (du kan h�gertrunkera med *) och klicka p� s�k</strong><br />
		  <input name="searchterm[1]" type="text" value="" size="45"/>
                  <input type="submit" value="S�k" /><br />
                  <strong>Du kan ocks� begr�nsa din s�kning till n�got
	          av biblioteken nedan (ej implementerat)</strong>
                  <hr />
	      </td>
	    </tr>

            <tr  class="navigation">

	      <td class="left"><input name="searchfield[2]" type="hidden" value="set" />
		<!-- input name="searchterm[2]" type="radio"
		    value="gub" /-->G�teborgs Universitetsbibliotek
              </td>
	      <td class="left"><input name="searchfield[2]" type="hidden" value="set" />
		<!--input name="searchterm[2]" type="radio"
		    value="KB" / -->Kungl. Biblioteket Stockholm
              </td>
	    </tr>

	    <tr  class="navigation">
	      <td class="left">
		<input name="searchfield[2]" type="hidden" value="set" />
		<!--input name="searchterm[2]" type="radio"
		    value="lub" / -->Lunds Universitets Bibliotek
	      </td>
	      <td class="left"><input name="searchfield[2]" type="hidden" value="set" />
		<!--input name="searchterm[2]" type="radio"
		    value="uub" /-->Uppsala Universitetsbibliotek
              </td>
	    </tr>


            <tr  class="navigation"><td class="center" colspan="2">
		<input name="searchfield[2]" type="hidden" value="set" />
		<input name="searchterm[2]" type="radio"
		    value="" checked="checked" />Samtliga deltagande bibliotek
            </td></tr>

	  </table>
	  </form>

');

print ($sidfot_start);
?>
