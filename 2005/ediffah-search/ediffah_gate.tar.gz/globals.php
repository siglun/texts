<?php

$searchtop = '/home/sigge/WWW/2005/ediffah-search/';

$fragments = "$searchtop/fragments";
$huvud     = "$fragments/sid_huvud.text";
$fot       = "$fragments/sid_fot.text";

$search='http://sigge.lub.lu.se/2005/ediffah-search/search.php';
$maxfields = 3;

$num_hosts = count ($host);
$zhost= 'bourree.lub.lu.se:2121/ediffah';

$xslt_file          = "$searchtop/ediffah-hit.xsl";
$xslt_file_detailed = "$searchtop/ediffah-hit-detailed.xsl";

$fields	= array ("any"            => utf8_encode('Alla f�lt'),
		 "genreform"      => utf8_encode('Typer av handlingar'),
		 "occupation"     => utf8_encode('Yrkesbeteckning'),
		 "origination"    => utf8_encode('Arkivbildare'),
		 "persname"       => utf8_encode('Personnamn'),
		 "title"          => utf8_encode('Arkivf�rteckningens titel'),
		 "unittitle"      => utf8_encode('Titel'),
		 "subject"        => utf8_encode('�mnesord'),
		 "description"    => utf8_encode('Sammanfattning'),
		 );



$headingfields	= array ("genreform"      => utf8_encode('Typer av handlingar'),
			 "occupation"     => utf8_encode('Yrkesbeteckning'),
			 "persname"       => utf8_encode('Personnamn'),
/*			 "corpname"       => utf8_encode('Organisation'),*/
/*			 "famname"        => utf8_encode('Familjenamn'),*/
/*			 "function"       => utf8_encode('Funktion'),*/
/*			 "geogname"       => utf8_encode('Geografiskt namn'),*/
			 "origination"    => utf8_encode('Arkivbildare'),
			 "subject"        => utf8_encode('�mnesord'),
/*			 "heading-title"  => utf8_encode('Verkstitel')*/
			 );


$headings = array ("genreform"  => '@attr 1=5090 ',
		   "occupation" => '@attr 1=5110 ',
		   "persname"   => '@attr 1=5120 ',
		   "corpname"   => '@attr 1=5060 ',
		   "famname"    => '@attr 1=5070 ',
		   "function"   => '@attr 1=5080 ',
		   "geogname"   => '@attr 1=5100 ',
		   "subject"    => '@attr 1=5130 ',
		   "unittitle"  => '@attr 1=5240 ',
		   "origination"=> '@attr 1=5160 ',
		   "any"        => '@attr 1=1016',
		   "author"     => '@attr 1=5160',
		   "title"      => '@attr 1=4',
		   "description"=> '@attr 1=62',
		   "set"        => '@attr 1=5005',
		   );

$attributes = $headings;



$cclfields = array ("ti" => $attributes['title'],
		    "au" => $attributes['author'],
		    "ab" => $attributes['description'],
		    "su" => $attributes['subject'],
		    "pu" => $attributes['publisher']);


function initservice() {

header("Content-type: text/html; charset=UTF-8");

return 1;

}

?>
